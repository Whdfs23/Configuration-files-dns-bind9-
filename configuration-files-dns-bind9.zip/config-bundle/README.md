# Configuration Files — DNS Server BIND9 (Pertemuan 5)
Universitas Tidar — Konfigurasi dan Administrasi Sistem Jaringan (TFC409)

Server: 192.168.100.10 (ubuntu-server2026)
Domain: lab.local

## Daftar File

| File | Lokasi asli di server | Fungsi |
|---|---|---|
| named.conf.options | /etc/bind/named.conf.options | Global options: ACL, forwarders, rate-limiting, version-hiding, logging |
| named.conf.local | /etc/bind/named.conf.local | Deklarasi forward zone (lab.local) dan reverse zone (100.168.192.in-addr.arpa) |
| zones/db.lab.local | /etc/bind/zones/db.lab.local | Forward zone file — 5 A record, 3 CNAME, 1 MX, 1 TXT |
| zones/db.192.168.100 | /etc/bind/zones/db.192.168.100 | Reverse zone file — 6 PTR record |
| ufw-rules.sh | (dijalankan manual) | Firewall rules untuk membatasi akses port 53 hanya dari subnet lab |

## Cara Deploy Ulang (jika dibutuhkan)

```bash
sudo cp named.conf.options /etc/bind/named.conf.options
sudo cp named.conf.local /etc/bind/named.conf.local
sudo cp zones/db.lab.local /etc/bind/zones/db.lab.local
sudo cp zones/db.192.168.100 /etc/bind/zones/db.192.168.100
sudo chown bind:bind /etc/bind/zones/*
sudo named-checkconf
sudo named-checkzone lab.local /etc/bind/zones/db.lab.local
sudo named-checkzone 100.168.192.in-addr.arpa /etc/bind/zones/db.192.168.100
sudo systemctl restart bind9
```
