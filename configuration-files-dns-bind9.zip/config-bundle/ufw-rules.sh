#!/bin/bash
# =====================================================================
# FIREWALL RULES — DNS Server (BIND9) Security Hardening
# Praktikum Pertemuan 5 — dijalankan di ubuntu-server2026
# =====================================================================
# Tujuan: membatasi akses port 53 (DNS) HANYA dari subnet lab, sebagai
# lapisan pertahanan tambahan DI LUAR ACL BIND9 (defense in depth) —
# ACL bekerja di layer aplikasi BIND, firewall bekerja di layer OS/kernel.

# Izinkan query DNS (UDP & TCP) hanya dari subnet lab
sudo ufw allow from 192.168.100.0/24 to any port 53 proto udp
sudo ufw allow from 192.168.100.0/24 to any port 53 proto tcp

# Izinkan akses SSH untuk manajemen (dari subnet lab saja)
sudo ufw allow from 192.168.100.0/24 to any port 22

# Izinkan RNDC (remote control BIND) hanya dari localhost
sudo ufw allow from 127.0.0.1 to any port 953

# Tolak eksplisit akses port 53 dari luar subnet lab (defense in depth)
sudo ufw deny to any port 53

# Aktifkan firewall
sudo ufw --force enable

# Verifikasi
sudo ufw status verbose
